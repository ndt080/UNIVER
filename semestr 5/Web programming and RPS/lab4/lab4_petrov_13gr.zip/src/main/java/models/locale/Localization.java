package models.locale;

public enum Localization {
    EN, RU
}
