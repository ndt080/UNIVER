package models.exceptions;

public class UnresolvedLocaleException extends Exception {
    public UnresolvedLocaleException() {
        super();
    }

    public UnresolvedLocaleException(String msg) {
        super(msg);
    }
}
