const REGEXP_EMAIL = `^(([^<>()[\\]\\\\.,;:\\s@\\"]+(\\.[^<>()[\\]\\\\.,;:\\s@\\"]+)*)|(\\".+\\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$`;

function initInputValidation() {
    const inputs = document.querySelectorAll('[data-validation=true]');
    inputs.forEach((input) => {
        const errorBlock = createErrorBlock(input);
        input.parentNode.append(errorBlock);
        input.addEventListener('input', onInputChange);
    });
}

const onInputChange = (event) => {
    const input = event.target;
    const value = input.value;
    const validationType = input.attributes.getNamedItem('data-validation-type');
    const isValid = checkValidation(value, validationType.value);

    !isValid && createErrorMessage(input, validationType.value);
    isValid && removeErrorMessage(input);
}

const checkValidation = (value, validationType) => {
    const params = validationType.split('_');
    switch (params[0]) {
        case 'email': return new RegExp(REGEXP_EMAIL, "g").test(value);
        case 'numbers': return new RegExp("", "g").test(value);
        case 'max': return value.length <= Number(params[1]);
        case 'min': return value.length >= Number(params[1]);
        default: return true;
    }
}

const createErrorBlock = (input) => {
    const block = document.createElement('div');
    block.classList.add('form__error_message');
    block.setAttribute('for', input.id);
    return block;
}

const getErrorBlock = (input) => {
    return input.parentNode.querySelector(`[for=${input.id}]`);
}

const createErrorMessage = (input, validationType) => {
    const messageBlock = getErrorBlock(input);

    const type = validationType.split('_')[0];
    switch (type) {
        case 'email': {
            messageBlock.textContent = "Invalid email";
            break;
        }
        case 'numbers': {
            messageBlock.textContent = "Invalid char type";
            break;
        }
        case 'max': {
            messageBlock.textContent = "Invalid max length value";
            break;
        }
        case 'min': {
            messageBlock.textContent = "Invalid min length value";
            break;
        }
        default: {
            messageBlock.textContent = "Invalid value";
        }
    }
    input.parentNode.append(messageBlock);
}

const removeErrorMessage = (input) => {
    const messageBlock = getErrorBlock(input);
    messageBlock.textContent = "";
}


