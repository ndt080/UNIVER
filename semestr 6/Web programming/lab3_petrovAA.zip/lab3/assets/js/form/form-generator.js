function generateForm(targetFormId, formInputs, submitTitle) {
    const form = document.getElementById(targetFormId);

    const groupBlocks = formInputs.map((inputData, index) => {
        const inputId = createInputId(targetFormId, index);

        const groupBlock = createFormGroupBlock();
        const label = createLabel(inputData, inputId);
        const input = createInput(inputData, inputId);

        label.append(input);
        groupBlock.append(label);
        return groupBlock;
    });

    const groupBtnBlock = createFormGroupBlock();
    const submitBtn = createSubmitButton(submitTitle);
    groupBtnBlock.append(submitBtn);
    groupBlocks.push(groupBtnBlock);

    form.append(...groupBlocks);
}

const createInputId = (formId, index) => `${formId}_input-${index}`;

const createInput = (inputData, inputId) => {
    const input = document.createElement('input');
    input.type = inputData?.type || 'text';
    input.name = inputData?.name;
    input.id = inputId;
    input.placeholder = inputData?.placeholder || "Enter value...";
    input.classList.add('form__input', ...inputData?.styleClasses);

    inputData?.attributes && inputData?.attributes.forEach((value, key) => {
        input.setAttribute(key, value);
    });
    return input;
}

const createLabel = (inputData, inputId) => {
    const label = document.createElement('label');
    label.textContent = inputData?.label || 'Unknown field';
    label.setAttribute('for', inputId);
    label.classList.add('form__label');
    return label;
}

const createSubmitButton = (btnTitle) => {
    const button = document.createElement('button');
    button.classList.add('form__button');
    button.type = 'submit';
    button.textContent = btnTitle || 'Submit';
    return button;
}

const createFormGroupBlock = () => {
    const block = document.createElement('div');
    block.classList.add('form__group');
    return block;
}

