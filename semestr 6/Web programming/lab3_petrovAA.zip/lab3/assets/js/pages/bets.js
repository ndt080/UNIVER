const bets = []

const BetsFormInputs = [
    {
        label: 'Client ID:',
        name: 'clientId',
        placeholder: 'Enter client id',
        styleClasses: [],
        type: "text",
        attributes: new Map([
            ['data-validation', 'true'],
            ['data-validation-type', 'min_5'],
        ])
    },
    {
        label: 'Client ID:',
        name: 'clientId',
        placeholder: 'Enter client id',
        styleClasses: [],
        type: "text",
        attributes: new Map([
            ['data-validation', 'true'],
            ['data-validation-type', 'email'],
        ])
    },
]

function onLoadPage() {
    generateNavigationBar(NavigationItems)
    generateForm('bets-form', BetsFormInputs, "Show bets");

    const form = document.getElementById('bets-form');
    form.onsubmit = (e) => {
        e.preventDefault();
        // const formData = new FormData(e.target);
    };

    initInputValidation();
}


function printBets() {

}
