package mypack;

import javax.swing.*;
import javax.swing.event.TableModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.table.TableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.util.*;

public class Catalog extends JFrame {

    public static CookNode addResult = null;
    public static String path = null;
    JTable infoPanel = new JTable();
    JTree cookTree = new JTree();
    myTableModel tableModel = null;
    myTreeModel treeModel = null;

    public Catalog() throws HeadlessException {
        JButton addButton = new JButton("Добавить блюдо в кулинарную книгу");
        addButton.addActionListener(e -> SwingUtilities.invokeLater(() -> openAddDialog()));

        JButton removeButton = new JButton("Удалить блюдо из книги");
        removeButton.addActionListener(e -> removeItem());

        tableModel = new myTableModel();
        infoPanel = new JTable(tableModel);
        treeModel = new myTreeModel(new treeNode("Книга"));
        cookTree = new JTree(treeModel);

        cookTree.addTreeSelectionListener(new TreeSelectionListener() {
            @Override
            public void valueChanged(TreeSelectionEvent e) {
                treeNode node = (treeNode) cookTree.getLastSelectedPathComponent();
                if (node == null) {
                    return;
                }
                ArrayList<CookNode> array = node.getAllNodes();
                tableModel = new myTableModel(array);
                infoPanel.setModel(tableModel);
            }
        });
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true, new JScrollPane(cookTree), new JScrollPane(infoPanel));
        splitPane.setDividerLocation(200);


        JSplitPane splitBTNPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,true,addButton,removeButton);
        getContentPane().add(splitPane);
        getContentPane().add("North", splitBTNPane);
        setBounds(100, 100, 600, 600);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        Catalog mainClass = new Catalog();
        mainClass.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        mainClass.setVisible(true);
    }

    public void openAddDialog() {
        MyFrame myFrameForm = new MyFrame(this);
        myFrameForm.setVisible(true);
    }

    public void addNewItem() {
        treeNode temp, where, insert, root = treeModel.getRoot();

        try {
            insert = new treeNode(addResult.name, addResult);
            if ((where = findNode(root, addResult.level)) != null) {
                treeModel.insertNodeInto(insert, where, where.getChildCount(), false);
            } else if (findNode(root, addResult.type) != null) {
                treeModel.insertNodeInto(new treeNode(addResult.level), (temp = findNode(root, addResult.type)), temp.getChildCount(), false);
                where = findNode(root, addResult.level);
                treeModel.insertNodeInto(insert, where, where.getChildCount(), false);
            } else if (findNode(root, addResult.worldCuisine) != null) {
                treeModel.insertNodeInto(new treeNode(addResult.type), (temp = findNode(root, addResult.worldCuisine)), temp.getChildCount(), false);
                treeModel.insertNodeInto(new treeNode(addResult.level), (temp = findNode(root, addResult.type)), temp.getChildCount(), false);
                where = findNode(root, addResult.level);
                treeModel.insertNodeInto(insert, where, where.getChildCount(), false);
            } else {
                treeModel.insertNodeInto(new treeNode(addResult.worldCuisine), root, root.getChildCount(), false);
                treeModel.insertNodeInto(new treeNode(addResult.type), (temp = findNode(root, addResult.worldCuisine)), temp.getChildCount(), false);
                treeModel.insertNodeInto(new treeNode(addResult.level), (temp = findNode(root, addResult.type)), temp.getChildCount(), false);
                where = findNode(root, addResult.level);
                treeModel.insertNodeInto(insert, where, where.getChildCount(), false);
            }
        } catch (Exception e) {
            path = null;
            addResult = null;
            return;
        }

        path = null;
        addResult = null;
    }

    public void removeItem() {
        TreePath currentSelection = cookTree.getSelectionPath();
        if (currentSelection != null) {
            treeNode currentNode = (treeNode) (currentSelection.getLastPathComponent());
            treeNode parent = (treeNode) (currentNode.getParent());
            if (parent != null) {
                treeModel.removeNodeFromParent(currentNode);
                parent.deleteNode(currentNode);
                ArrayList<CookNode> array = parent.getAllNodes();
                tableModel = new myTableModel(array);
                infoPanel.setModel(tableModel);
            }
        }
    }

    public treeNode findNode(treeNode root, String s) {
        var e = root.depthFirstEnumeration();
        while (e.hasMoreElements()) {
            var node = e.nextElement();
            if (node.toString().equalsIgnoreCase(s)) {
                return (treeNode) node;
            }
        }
        return null;
    }
}

class myTreeModel extends DefaultTreeModel {

    private treeNode root;

    public myTreeModel(treeNode r) {
        super(r);
        root = r;
    }

    @Override
    public treeNode getRoot() {
        return root;
    }

    public void insertNodeInto(treeNode child, treeNode parent, int i, boolean flag) {
        this.insertNodeInto(child, parent, i);
        parent.addNode(child);
    }
}

class myTableModel implements TableModel {
    static final String[] columnNames = new String[]{"Название", "Сложность", "Тип", "Категория кухни"};
    static final Class[] columnTypes = new Class[]{String.class, String.class, String.class, String.class, String.class, Integer.class, Integer.class};
    private Set<TableModelListener> listeners = new HashSet<TableModelListener>();
    private ArrayList<CookNode> infoNodes;

    public myTableModel() {
        infoNodes = new ArrayList<CookNode>();
    }

    public myTableModel(ArrayList<CookNode> al) {
        this.infoNodes = al;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        CookNode nb = infoNodes.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return nb.getName();
            case 1:
                return nb.getWorldCuisine();
            case 2:
                return nb.getType();
            case 3:
                return nb.getLevel();
        }
        return "";
    }

    public int getColumnCount() {
        return columnNames.length;
    }

    public int getRowCount() {
        return infoNodes.size();
    }

    public Class getColumnClass(int columnIndex) {
        return columnTypes[columnIndex];
    }

    public String getColumnName(int columnIndex) {
        return columnNames[columnIndex];
    }

    public void setInfoArray(ArrayList<CookNode> al) {
        infoNodes = al;
    }

    @Override
    public void addTableModelListener(TableModelListener listener) {
        listeners.add(listener);
    }

    @Override
    public void removeTableModelListener(TableModelListener listener) {
        listeners.remove(listener);
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }

    @Override
    public void setValueAt(Object value, int rowIndex, int columnIndex) {
    }
}

class treeNode extends DefaultMutableTreeNode {
    String name;
    CookNode ifNode = null;
    ArrayList<treeNode> nodes;
    boolean isThisTheEnd = false;

    public treeNode() {
        name = "-";
        nodes = new ArrayList<treeNode>();
        ifNode = null;
        isThisTheEnd = false;
    }

    public treeNode(String str) {
        name = str;
        nodes = new ArrayList<treeNode>();
        ifNode = null;
        isThisTheEnd = false;
    }

    public treeNode(String str, CookNode nbNode) {
        name = str;
        nodes = new ArrayList<treeNode>();
        ifNode = nbNode;
        isThisTheEnd = true;
    }

    public ArrayList<CookNode> getAllNodes() {
        ArrayList<CookNode> ret = new ArrayList<CookNode>();
        Deque<treeNode> deque = new ArrayDeque<treeNode>();

        treeNode temp;
        deque.push(this);
        while (!deque.isEmpty()) {
            temp = deque.removeFirst();
            if (temp.isThisTheEnd) {
                ret.add(temp.getIfNode());
            } else {
                for (int i = 0; i < temp.nodes.size(); i++) {
                    deque.push(temp.nodes.get(i));
                }
            }
        }
        return ret;
    }

    public void addNode(treeNode tn) {
        nodes.add(tn);
    }

    public void deleteNode(treeNode tn) {
        for (int i = 0; i < nodes.size(); i++) {
            if (nodes.get(i).toString().compareToIgnoreCase(tn.toString()) == 0) {
                nodes.remove(i);
            }
        }
    }

    public CookNode getIfNode() {
        return ifNode;
    }
    public String toString() {
        return name;
    }
}

class CookNode {
    String name, worldCuisine, type, level;

    CookNode(String worldCuisine, String type, String level, String name) {
        this.worldCuisine = worldCuisine;
        this.type = type;
        this.level = level;
        this.name = name;
    }

    public String getName() { return name; }

    public String getWorldCuisine() {
        return worldCuisine;
    }

    public String getLevel() {
        return level;
    }

    public String getType() {
        return type;
    }
}