import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "Game", urlPatterns = {"/game"})
public class Game extends HttpServlet {
    String pickPlayer = "Guest";
    public void init() throws ServletException {
        super.init();
    }

    public void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        performTask(req, resp);
    }

    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        performTask(req, resp);
    }

    public void performTask(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String parma = req.getParameter("p0");
        Hand playerOne = new Hand();
        Hand dealer = new Hand();
        if(parma != null){
            pickPlayer = parma;
        }

        PrintWriter out = resp.getWriter();
        out.print(
        "<!DOCTYPE html>\n" +
                "<head>\n" +
                "    <meta charset=\"utf-8\">\n" +
                "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">\n" +
                "    <title>Twenty One Game!</title>\n" +
                "    <meta name=\"description\" content=\"\">\n" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
                "\n" +
                "    <link rel=\"stylesheet\" href=\"css/normalize.css\">\n" +
                "    <link rel=\"stylesheet\" href=\"css/main.css\">\n" +
                "</head>\n" +
                "\n" +
                "<body>\n" +
                "<div class=\"main\">\n" +
                "    <h1>Twenty One Game</h1>\n" +
                "    <input onClick=\"window.location.href='/'\" type=\"button\" id = \"reset\" Value=\"Back home\">" +
                "    <input onClick=\"window.location.href='/game'\" type=\"button\" id = \"reset\" Value=\"Reset game!\">" +
                "    <section>\n" +
                "        <p id=\"results\"><i>"+
                pickPlayer + " has a score of: " + playerOne.getScope() + "<br>" + "Dealer has a score of "
                + dealer.getScope() + " <br> <br>"+ checkWins(pickPlayer, playerOne, dealer)
                +"</i></p>\n" +
                "    </section>\n" +
                "</div>\n" +
                "\n" +
                "</body>\n" +
                "\n" +
                "</html>\n");
    }

    private String checkWins(String name, Hand playerOne, Hand dealer) {
        if (playerOne.getScope() > dealer.getScope()) {
            return name + " wins";
        }
        else if (playerOne.getScope() < dealer.getScope()) {
            return "Dealer wins";
        }
        else {
            return "It's a tie!";
        }
    };

}