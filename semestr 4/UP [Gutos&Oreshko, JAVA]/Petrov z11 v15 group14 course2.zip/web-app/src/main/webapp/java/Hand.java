class Hand{
    Card card1;
    Card card2;
    public Hand() {
        card1 = deal();
        card2 = deal();
    }

    public Card deal(){
        int ranNum = (int) (Math.floor(Math.random () * 13) + 1);
        return new Card (ranNum);
    }
    public int getScope(){
        int score1 = card1.getValue();
        int score2 = card2.getValue();
        return score1 + score2;
    }
}