class Card {
    private final int number;

    public Card(int nb) {
        number = nb;
    }
    public int getValue() {
        if (number > 11) {
            return 10;
        } else if (number == 1) {
            return 11;
        } else {
            return number;
        }
    }
}