package sample;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class BattleshipServer {
    public static void main(String[] args){
        try{
            BattleshipInterface obj = new BattleshipImplementationM();
            Registry rgsty = LocateRegistry.createRegistry(5000);
            rgsty.rebind("BattleshipImplementationobj", obj);
        }
        catch(Exception e){
            System.out.println("Exception while binding object :"+ e.getMessage());
            e.printStackTrace();
        }
    }
}