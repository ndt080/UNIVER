package bsu.fpmi.edupract;

/**
 *
 * @author Andrei Petrov
 */

import java.util.ArrayList;
import javax.swing.JOptionPane;


public class myNewPanel extends javax.swing.JPanel {
    private javax.swing.JButton jButton;
    private javax.swing.JComboBox<String> jComboBox;
    private javax.swing.JLabel jLabel;
    private char commandKey = 'z';
    ArrayList<String> comboBoxes=new ArrayList<String>();
    
    public myNewPanel() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel = new javax.swing.JLabel();
        jButton = new javax.swing.JButton();
        jComboBox = new javax.swing.JComboBox<>();

        jLabel.setText("Click on button");

        jButton.setText("Button");
        jButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButtonMousePressed(evt);
            }
        });
        jButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonActionPerformed(evt);
            }
        });
        jButton.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButtonKeyPressed(evt);
            }
        });

        jComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxActionPerformed(evt);
            }
        });
        jComboBox.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jComboBoxKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(29, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(23, 23, 23))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(100, Short.MAX_VALUE))
        );
    }// </editor-fold>

    private void jButtonActionPerformed(java.awt.event.ActionEvent evt) { }

    private void jComboBoxActionPerformed(java.awt.event.ActionEvent evt) { }

    private void jButtonMousePressed(java.awt.event.MouseEvent evt) {
        showInfo("Button");
    }

    private void jButtonKeyPressed(java.awt.event.KeyEvent evt) {
        keyPressed(evt.getKeyChar());
    }

    private void jComboBoxKeyPressed(java.awt.event.KeyEvent evt) {
        keyPressed(evt.getKeyChar());
    }

    private void showInfo(String pressed) {
        JOptionPane.showMessageDialog(this, "Selected items index = " + 
                jComboBox.getSelectedIndex() + "\n" + pressed + " pressed");
        jButton.setVisible(true);
    }

    private void keyPressed(char ev) {
        if (ev == commandKey) {
            showInfo("Command key");
        }
    }

    public void setComboBoxText(String[] lines) {
        jComboBox.removeAllItems();
        for (String line :lines) {
            jComboBox.addItem(line);
        }
    }

    public void setjLabel(String labels) {
        jLabel.setText(labels);
    }

    public String getjLabel() {
        return jLabel.getText();
    }


    public void setjButton(String buttons) {
        jButton.setText(buttons);
    }

    public String getjButton() {
        return jButton.getText();
    }
}
