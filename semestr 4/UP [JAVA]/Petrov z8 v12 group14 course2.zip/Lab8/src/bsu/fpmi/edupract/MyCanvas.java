package bsu.fpmi.edupract;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;


public class MyCanvas extends Canvas {
    private int diam;
    private Color color;

    public void setDiametr(int d) {
        this.diam = d;
    }
    
    public void setColor(Color c) {
        this.color = c;
    }

    public MyCanvas() {
        this(Color.BLUE, 250);
        this.setSize(new Dimension(250, 250));
    }
    
    public MyCanvas(Color c, int d) {
        this.color = c;
        this.diam = d;
    }
    
    @Override
    public void paint(Graphics g) {
        Graphics2D g2d = (Graphics2D)g;
        Shape circle = new Ellipse2D.Float(0, 0 ,diam, diam );
        g2d.draw(circle);
        g2d.setColor(color);
        g2d.fill(circle);
    }
}