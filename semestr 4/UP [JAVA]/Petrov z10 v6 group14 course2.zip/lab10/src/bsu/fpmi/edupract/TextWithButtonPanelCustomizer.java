package bsu.fpmi.edupract;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import javax.swing.JOptionPane;

/**
 * This class is a customizer for the TextWithButtonPanel bean.  It displays a
 * TextArea and three TextFields where the user can enter the main messageText
 * and the labels for each of the three buttons.  It does not allow the
 * alignment property to be set.
 **/
public class TextWithButtonPanelCustomizer extends Panel
        implements Customizer, TextListener
{
    protected TextWithButtonPanel bean;    // The bean being customized
    protected TextField messageField;   // For entering the messageText    
    protected TextField buttonField; // For entering button text

    // The bean box calls this method to tell us what object to customize.
    // This method will always be called before the customizer is displayed,
    // so it is safe to create the customizer GUI here.
    public void setObject(Object obj) {
        bean = (TextWithButtonPanel)obj;   // save the object we're customizing

        // Put a label at the top of the panel.
        this.setLayout(new BorderLayout());
        this.add(new Label("Enter the message to appear in the panel:"),
                "North");

        // And a buttonField below it for entering the messageText.
        messageField = new TextField(bean.getMessageText());
        messageField.addTextListener(this);
        this.add(messageField, "Center");

        // Then add a row of textbuttonFields for entering the button labels.
        Panel buttonbox = new Panel();                     // The row container
        buttonbox.setLayout(new GridLayout(1, 0, 25, 10)); // Equally spaced
        this.add(buttonbox, "South");                      // Put row on bottom

        // Now go create three TextFields to put in this row.  But actually
        // position a Label above each, so create an container for each
        // TextField+Label combination.
        buttonField = new TextField();               // Array of TextFields.
        String label = "Button Label";
        String value = bean.getSimpleButtonLabel();

        Panel p = new Panel();                 // Create a container.
        p.setLayout(new BorderLayout());       // Give it a BorderLayout.
        p.add(new Label(label), "North");  // Put a label on the top.
        buttonField = new TextField(value);  // Create the text buttonField.
        p.add(buttonField, "Center");            // Put it below the label.
        buttonField.addTextListener(this);       // Set the event listener.
        buttonbox.add(p);                      // Add container to row.
    }
    // Add some space around the outside of the panel.
    public Insets getInsets() { return new Insets(10, 10, 10, 10); }

    // This is the method defined by the TextListener interface.  Whenever the
    // user types a character in the TextArea or TextFields, this will get
    // called.  It updates the appropriate property of the bean and fires a
    // property changed event, as all customizers are required to do.
    // Note that we are not required to fire an event for every keystroke.
    // Instead we could include an "Apply" button that would make all the
    // changes at once, with a single property changed event.
    public void textValueChanged(TextEvent e) {
        TextComponent t = (TextComponent)e.getSource();
        String s = t.getText();
         JOptionPane.showMessageDialog(bean, s);
        if (t == messageField) bean.setMessageText(s);
        else if (t == buttonField) bean.setSimpleButtonLabel(s);
        listeners.firePropertyChange(null, null, null);
    }

    // This code uses the PropertyChangeSupport class to maintain a list of
    // listeners interested in the edits we make to the bean.
    protected PropertyChangeSupport listeners =new PropertyChangeSupport(this);
    public void addPropertyChangeListener(PropertyChangeListener l) {
        listeners.addPropertyChangeListener(l);
    }
    public void removePropertyChangeListener(PropertyChangeListener l) {
        listeners.removePropertyChangeListener(l);
    }
}

