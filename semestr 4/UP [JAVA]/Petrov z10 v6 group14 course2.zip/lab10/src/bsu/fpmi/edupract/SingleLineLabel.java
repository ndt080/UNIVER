package bsu.fpmi.edupract;

import java.awt.*;

public class SingleLineLabel extends Canvas{
    // User-specified properties
    protected String label;
    protected Alignment alignment;      // The alignment of the text.

    // Computed state values
    protected String line;           // The label, broken into lines
    protected int line_width;        // How wide each line is
    protected int max_width;            // The width of the widest line
    protected int line_height;          // Total height of the font
    protected boolean measured = false;

    // Here are five versions of the constructor.
    public SingleLineLabel(String label, Alignment alignment) {
        this.label = label;                 // Remember all the properties.
        this.alignment = alignment;
        newLabel();                         // Break the label up into lines.
    }

    public SingleLineLabel(String label) {
        this(label, Alignment.LEFT);
    }

    public SingleLineLabel() {
        this("Some data");
    }
    // Methods to set and query the various attributes of the component.
    // Note that some query methods are inherited from the superclass.
    public void setLabel(String label) {
        this.label = label;
        newLabel();               // Break the label into lines.
        measured = false;         // Note that we need to measure lines.
        repaint();                // Request a redraw.
    }

    public void setAlignment(Alignment a) {
        alignment = a;
        repaint();
    }

    public void setForeground(Color c) {
        super.setForeground(c);   // Tell our superclass about the new color.
        repaint();                // Request a redraw (size is unchanged).
    }

    // Property getter methods.  Note that getFont(), getForeground(), etc.
    // are inherited from the superclass.

    public String getLabel() { return label; }

    /**
     * This method is called by a layout manager when it wants to
     * know how big we'd like to be.  In Java 1.1, getPreferredSize() is
     * the preferred version of this method.  We use this deprecated version
     * so that this component can interoperate with 1.0 components.
     */
    public Dimension getPreferredSize() {
        if (!measured) measure();
        return new Dimension(max_width + 20, line_height + 20);
    }

    /**
     * This method is called when the layout manager wants to know
     * the bare minimum amount of space we need to get by.
     * For Java 1.1, we'd use getMinimumSize().
     */
    public Dimension getMinimumSize() { return getPreferredSize(); }

    /**
     * This method draws the component.
     * Note that it handles the margins and the alignment, but that
     * it doesn't have to worry about the color or font--the superclass
     * takes care of setting those in the Graphics object we're passed.
     **/
    public void paint(Graphics g) {
        int x, y;
        Dimension size = this.getSize();  // use getSize() in Java 1.1

        if (!measured) measure();

        if (alignment == Alignment.RIGHT) {
            x = size.width - line_width;
        }
        else if (alignment == Alignment.CENTER) {
            x = (size.width - line_width) / 2;
        }
        else {
            x = 0;
        }

        y = (size.height - line_height) / 2;

        g.drawString(line, x, y);
    }

    /**
     * This internal method breaks a specified label up into an array of lines.
     * It uses the StringTokenizer utility class.
     **/
    protected synchronized void newLabel() {
        line = label;
    }

    /**
     * This internal method figures out how the font is, and how wide each
     * line of the label is, and how wide the widest line is.
     **/
    protected synchronized void measure() {
        FontMetrics fm = this.getFontMetrics(this.getFont());
        line_height = fm.getHeight();
        max_width = 0;

        line_width = fm.stringWidth(line);

        measured = true;
    }
}
