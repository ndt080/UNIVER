package bsu.fpmi.edupract;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.Vector;

public class TextWithButtonPanel extends Panel{
    protected String messageText;  // The message to display
    protected Alignment alignment; // The alignment of the message
    protected String simpleButtonLabel;     // Text for the simpleButton button
    protected String[] listText;

    // Internal components of the panel
    protected SingleLineLabel message;
    protected Button simpleButton;
    protected javax.swing.JList<String> list;


    /** The no-argument bean constructor, with default property values */
    public TextWithButtonPanel() {
        this("Your Message Here");
    }

    public TextWithButtonPanel(String messageText) {
        this(messageText, new String[] {"item1", "item2", "item3", "item4"});
    }

    public TextWithButtonPanel(String messageText, String[] listText) {
        this(messageText, listText, "OK");
    }

    /** A constructor for programmers using this class "by hand" */
    public TextWithButtonPanel(String messageText, String[] listText, String simpleButtonLabel)
    {
        // Create the components for this panel
        setLayout(new BorderLayout(15, 15));

        // Put the message label in the middle of the window.
        message = new SingleLineLabel(messageText);
        add(message, BorderLayout.NORTH);

        // Create a panel for the Panel buttons and put it at the bottom
        // of the Panel.  Specify a FlowLayout layout manager for it.
        Panel buttonbox = new Panel();
        buttonbox.setLayout(new FlowLayout(FlowLayout.CENTER, 25, 15));
        add(buttonbox, BorderLayout.SOUTH);

        // Create each specified button, specifying the action listener
        // and action command for each, and adding them to the buttonbox
        simpleButton = new Button();                   // Create buttons

        // Add the button to the button box
        buttonbox.add(simpleButton);


        // Register listeners for each button
        simpleButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                fireEvent(new AcceptEvent(TextWithButtonPanel.this));
            }
        });

        list = new javax.swing.JList<>();
        //list.setModel(new javax.swing.DefaultListModel<>());
        add(list, BorderLayout.CENTER);

        // Now call property setter methods to set the message and button
        // components to contain the right text
        setMessageText(messageText);
        setSimpleButtonLabel(simpleButtonLabel);
        setListText(listText);
    }

    // Methods to query all of the bean properties.
    public String getMessageText() { return messageText; }
    public String getSimpleButtonLabel() { return simpleButtonLabel; }
    public Alignment getAlignment() { return alignment; }
    public String[] getListText() { return listText; }

    // Methods to set all of the bean properties.
    public void setMessageText(String messageText) {
        this.messageText = messageText;
        message.setLabel(messageText);
        validate();
    }

    public void setAlignment(Alignment alignment) {
        this.alignment = alignment;
        message.setAlignment(alignment);
    }

    public void setListText(String[] listText) {
        this.listText = listText;
        list.setListData(listText);
        validate();
    }

    public void setSimpleButtonLabel(String l) {
        simpleButtonLabel = l;
        simpleButton.setLabel(l);
        simpleButton.setVisible((l != null) && (l.length() > 0));
        validate();
    }

    public void setFont(Font f) {
        super.setFont(f);    // Invoke the superclass method
        message.setFont(f);
        simpleButton.setFont(f);
        list.setFont(f);
        validate();
    }

    /** This field holds a list of registered ActionListeners. */
    protected Vector<AcceptListener> listeners = new Vector<>();

    /** Register an action listener to be notified when a button is pressed */
    public void addAcceptListener(AcceptListener l) {
        listeners.addElement(l);
    }

    /** Remove an Accept listener from our list of interested listeners */
    public void removeAcceptListener(AcceptListener l) {
        listeners.removeElement(l);
    }

    /** Send an event to all registered listeners */
    public void fireEvent(AcceptEvent e) {
        // Make a copy of the list and fire the events using that copy.
        // This means that listeners can be added or removed from the original
        // list in response to this event.  We ought to be able to just use an
        // enumeration for the vector, but that doesn't actually copy the list.
        Vector list = (Vector) listeners.clone();
        for(int i = 0; i < list.size(); i++) {
            AcceptListener listener = (AcceptListener)list.elementAt(i);
            AcceptEvent: listener.simpleButton(e); break;
        }
    }

    /** A main method that demonstrates the class */
    public static void main(String[] args) throws IOException {
        // Create an instance of InfoPanel, with title and message specified:
        TextWithButtonPanel p = new TextWithButtonPanel("Do you really want to quit?");

        // Register an action listener for the Panel.  This one just prints
        // the results out to the console.
        p.addAcceptListener(new AcceptListener() {
            public void simpleButton(AcceptEvent e) {
                System.out.printf("Selected row index: %d", p.list.getLeadSelectionIndex());
                JOptionPane.showMessageDialog(p, "Selected items index = " + 
                    p.list.getLeadSelectionIndex());
                p.setMessageText("Selected row index: " + p.list.getLeadSelectionIndex());
                System.exit(0);
            }
        });

        Frame f = new Frame();
        f.add(p);
        f.pack();
        f.setVisible(true);
    }
}
