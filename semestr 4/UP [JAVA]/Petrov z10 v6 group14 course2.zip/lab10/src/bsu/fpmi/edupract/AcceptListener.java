package bsu.fpmi.edupract;

public interface AcceptListener extends java.util.EventListener {
    public void simpleButton(AcceptEvent e);
}
