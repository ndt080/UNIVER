package bsu.fpmi.edupract;

public class AcceptEvent extends java.util.EventObject {
    public AcceptEvent(Object source) {
        super(source);
    }
}
