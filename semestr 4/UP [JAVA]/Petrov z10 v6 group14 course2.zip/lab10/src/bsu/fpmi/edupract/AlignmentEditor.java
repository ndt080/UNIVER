package bsu.fpmi.edupract;
import java.beans.*;
import java.awt.*;

public class AlignmentEditor extends PropertyEditorSupport {
    /** Return the list of value names for the enumerated type. */
    public String[] getTags() {
        return new String[] { "left", "center", "right" };
    }

    /** Convert each of those value names into the actual value. */
    public void setAsText(String s) {
        if (s.equals("left")) setValue(Alignment.LEFT);
        else if (s.equals("center")) setValue(Alignment.CENTER);
        else if (s.equals("right")) setValue(Alignment.RIGHT);
        else throw new IllegalArgumentException(s);
    }

    /** This is an important method for code generation. */
    public String getJavaInitializationString() {
        Object o = getValue();
        if (o == Alignment.LEFT)
            return "Alignment.LEFT";
        if (o == Alignment.CENTER)
            return "Alignment.CENTER";
        if (o == Alignment.RIGHT)
            return "Alignment.RIGHT";
        return null;
    }
}
