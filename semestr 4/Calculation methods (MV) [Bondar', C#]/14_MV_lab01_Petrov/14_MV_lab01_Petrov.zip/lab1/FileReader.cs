﻿using System.IO;

namespace lab1
{
    public class FileReader
    {
        public static double[,] ReadMatrix(string path)
        {
            using var sr = new StreamReader(path, System.Text.Encoding.Default);
            var digits = sr.ReadLine()!.Split(' ');
            var n = int.Parse(digits[0]);
            var m = int.Parse(digits[1]);
            var matrix = new double[n, m];

            sr.ReadLine();
            for (var i = 0; i < n; i++)
            {
                digits = sr.ReadLine()!.Split(' ');
                for (var j = 0; j < m; j++)
                {
                    matrix[i, j] = double.Parse(digits[j]);
                }
            }

            return matrix;
        }

        public static double[] ReadVector(string path)
        {
            using var sr = new StreamReader(path, System.Text.Encoding.Default);
            var digit = sr.ReadLine()!;
            var n = int.Parse(digit!);
            var vec = new double[n];

            sr.ReadLine();
            for (var i = 0; i < n; i++)
            {
                digit = sr.ReadLine();
                vec[i] = double.Parse(digit!);
            }

            return vec;
        }
    }
}