﻿using System;
using System.Diagnostics;
using MathNet.Numerics.LinearAlgebra;

namespace lab1
{
    internal static class Program
    {
        private static void Main()
        {
            /*
            var A = Matrix<double>.Build.Random(5000, 5000);
            var b = Vector<double>.Build.Random(5000);
            // for (var i = 0; i < 10; i++)
            //     b[i] = (i % 2 != 0) ?  b[i] + 0.001 : b[i] - 0.001;
            */
            var A = Matrix<double>.Build.DenseOfArray(FileReader.ReadMatrix("../../../resources/matrix1.txt"));
            var b = Vector<double>.Build.DenseOfArray(FileReader.ReadVector("../../../resources/vector1.txt"));
            
            var stopWatch = new System.Diagnostics.Stopwatch();
            stopWatch.Start();
            var res = A.Reflection(b);
            stopWatch.Stop();
            var time = stopWatch.ElapsedMilliseconds;
            stopWatch.Reset();
            Console.WriteLine("log>\tResultat:\n\t{0} ",res.ToString());
            Console.WriteLine("log>\tDeterminant: {0}", A.QR().Determinant);
            Console.WriteLine("log>\tTime: {0} Milliseconds",time);
            
            stopWatch.Start();
            var res2 = A.Solve(b);
            stopWatch.Stop();
            time = stopWatch.ElapsedMilliseconds;
            stopWatch.Reset();
            Console.WriteLine("log>\tResult:\n\t{0} ", res2);
            Console.WriteLine("log>\tTime: {0} Milliseconds",time);

        }
    }
}