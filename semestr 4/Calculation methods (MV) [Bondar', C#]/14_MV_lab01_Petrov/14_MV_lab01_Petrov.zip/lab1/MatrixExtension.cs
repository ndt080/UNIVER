﻿using System;
using MathNet.Numerics.LinearAlgebra;

namespace lab1
{
    public static class MatrixExtension
    {
        public static Vector<double> Reflection(this Matrix<double> a, Vector<double> b)
        {
            var m = Matrix<double>.Build.Dense(a.RowCount, a.ColumnCount + 1);
            var x = Vector<double>.Build.Dense(a.RowCount);
            for (var i = 0; i < m.RowCount; i++)
            {
                for (var j = 0; j < m.ColumnCount - 1; j++)
                    m[i, j] = a[i, j];
                m[i, m.ColumnCount - 1] = b[i];
            }

            // w - верхний элемент вектора "омега", root - верхний элемент a~
            double w, root;
            for (var k = 0; k < m.ColumnCount - 2; k++)
            {
                root = m.FindLength(k, k);
                w = m[k, k] - root;
                m[k, k] = root;
                // a = a - 2*|aw|*w, где w - вектор "Омега", |aw| - скалярное произведение (scalarMultiply)
                // также нет необходимости непосредственно делить вектор "омега" на его длину,
                // в ходе вычислений длина выносится за скобки и возводится в квадрат (lengthIn2),
                // это позволяет увеличить точность, так как нам не надо считать квадратные корни и делить вектор на них
                var lengthIn2 = m.FindLengthIn2(k + 1, k) + w * w;

                for (var j = k + 1; j < m.ColumnCount; j++)
                {
                    var scalarMultiply = m[k, j] * w + m.ScalarMultiplyColumns(k + 1, m.RowCount, j, k);
                    m[k, j] = m[k, j] - 2 * scalarMultiply / lengthIn2 * w;
                    for (var i = k + 1; i < m.RowCount; i++)
                        m[i, j] = m[i, j] - 2 * scalarMultiply / lengthIn2 * m[i, k];
                }
                for (var i = k + 1; i < m.RowCount; i++)
                    m[i, k] = 0; // зануление нижних элементов a~
            }

            // выделяем вектор b из матрицы в вектор x 
            for (var i = 0; i < b.Count; i++)
                x[i] = m[i, m.ColumnCount - 1]; 
            
            for (var i = 1; i <= m.RowCount; i++)
            {
                double temp = 0;
                temp += x[^i];
                for (var j = 1; j < i; j++)
                    temp += m[m.RowCount - i, m.ColumnCount - j - 1] * -x[m.RowCount - j];

                x[^i] = temp / m[m.RowCount - i, m.ColumnCount - i - 1];
            }
            return x;
        }


        private static double FindLength(this Matrix<double> a, int row, int col)
        {
            return Math.Sqrt(a.FindLengthIn2(row, col));
        }

        private static double FindLengthIn2(this Matrix<double> a, int row, int col)
        {
            double temp = 0;
            for (var i = row; i < a.RowCount; i++)
            {
                temp += a[i, col] * a[i, col];
            }
            return temp;
        }

        private static double ScalarMultiplyColumns(this Matrix<double> a, int rowStart, int rowEnd, int col1, int col2)
        {
            double res = 0;
            for (int i = rowStart; i < rowEnd; i++)
            {
                res += a[i, col1] * a[i, col2];
            }
            return res;
        }
    }
}